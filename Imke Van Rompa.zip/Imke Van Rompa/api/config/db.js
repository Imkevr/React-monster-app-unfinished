module.exports = {
  url: "mongodb://imkeTest:KdGTJ2xN@ds219532.mlab.com:19532/notable"
};
